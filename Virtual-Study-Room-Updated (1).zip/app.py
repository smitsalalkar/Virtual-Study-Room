from flask import Flask, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, join_room, emit

app = Flask(__name__)
app.secret_key = "your_secret_key"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
socketio = SocketIO(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=False, unique=True)
    password = db.Column(db.String(50), nullable=False)

class Room(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    notes = db.Column(db.Text, default="")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            return redirect('/rooms')
        return "Invalid credentials"
    return render_template('login.html')

@app.route('/rooms', methods=['GET', 'POST'])
def rooms():
    if 'user_id' not in session:
        return redirect('/login')
    if request.method == 'POST':
        room_name = request.form['room_name']
        new_room = Room(name=room_name)
        db.session.add(new_room)
        db.session.commit()
    rooms = Room.query.all()
    return render_template('rooms.html', rooms=rooms)

@app.route('/room/<int:room_id>')
def room(room_id):
    if 'user_id' not in session:
        return redirect('/login')
    room = Room.query.get(room_id)
    return render_template('room.html', room=room)

@socketio.on('join')
def join(data):
    join_room(data['room'])
    emit('update_notes', data['notes'], room=data['room'])

@socketio.on('save_notes')
def save_notes(data):
    room = Room.query.get(data['room_id'])
    room.notes = data['notes']
    db.session.commit()
    emit('update_notes', data['notes'], room=str(data['room_id']))

if __name__ == '__main__':
    db.create_all()
    socketio.run(app)